extends CharacterBody2D


const SPEED = 300.0

const attacks = ["slash_into_large_slam",
 				"stab_into_smash",
 				"smash_into_smash",
				"double_slash",
				"double_slash_into_smash",
				"gundyr_grab",
				"jumping_slash"]
const decisions = ["walk",
				"attack"]

func _physics_process(delta: float) -> void:
	if $boss_animation_player.queue.length() == 0:
		decide()

func decide():
	var vector_to_player = (get_node("../player_body").global_position - global_position)
	if vector_to_player.length() > 300:
		velocity = vector_to_player.normalized*SPEED
		$boss_animation_player.play("walk")
	else:
		var choice = attacks.pick_random()
		match choice:
			"slash_into_large_slam":
				$boss_animation_player.queue("slash")
				$boss_animation_player.queue("slam")
