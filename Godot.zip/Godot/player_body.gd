extends CharacterBody2D

const speed = 150
var in_control = true

func _ready():
	$light_attack_area/light_attack_sprite.visible = false
	$light_attack_area/light_attack_collision.disabled = false
	
func get_input():
	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = input_direction * speed

func _physics_process(delta):
	get_input()
	if not in_control:
		velocity = Vector2(0,0)
	move_and_slide()
	if Input.is_action_pressed("left_click") and in_control:
		light_attack()

func light_attack():
	in_control = false
	$light_attack_startup.start()
	print("light_attack")

func _on_light_attack_startup_timeout():
	print("end of startup")
	$light_attack_active.start()

func _on_light_attack_active_timeout():
	$light_attack_area/light_attack_sprite.visible = true
	$light_attack_area/light_attack_collision.disabled = false
	$light_attack_recovery.start()

func _on_light_attack_recovery_timeout():
	$light_attack_area/light_attack_sprite.visible = false
	$light_attack_area/light_attack_collision.disabled = true
	in_control = true
